# Copilot instructions for this repository

Purpose: Help AI coding agents be productive editing this small, static academic website.

**Big Picture**:
- This repository is a minimal static site. The single entry point is `Academic Folder/Accademic.html` (note the filename spelling).
- Static assets live in the top-level `Image/` directory and are referenced by relative paths from the HTML file.
- There is no build system, package manager, server config, or tests present — changes are directly applied to files.

**Key files & folders**:
- `Academic Folder/Accademic.html`: main HTML page. Edit this file to change content, meta tags, or add new sections.
- `Image/`: image assets used by the HTML page. Preserve filenames and relative paths when updating images.

**Developer workflows (discoverable / applicable)**:
- Previewing changes: open `Academic Folder/Accademic.html` directly in a browser, or serve the repo root with a static server if available (example if Python is installed):

```
cd "c:/Users/TONY/Desktop/My Accademic site"
python -m http.server 8000
# then open http://localhost:8000/Academic%20Folder/Accademic.html
```

- There are no automated build/test/debug commands in this repo. Do not add build tooling unless instructed.

**Project-specific conventions & gotchas**:
- Filename & folder spelling matters: the folder is `Academic Folder` and the HTML file is `Accademic.html` (double-c). Do not rename files or folders without asking — other systems or links may rely on these exact names.
- Paths contain spaces. Use quoted strings or URL-encoding (`%20`) when constructing shell commands or links.
- Keep all edits minimal and backwards-compatible: this is a single-page static site; avoid introducing frameworks or complex folder restructuring.

**Patterns to follow when editing**:
- When adding images, place them in `Image/` and reference them with a relative path such as `../Image/my-photo.jpg` from inside `Academic Folder/`.
- Preserve existing HTML structure and inline styles unless the user requests a layout refactor.
- If adding new assets, update only the HTML references — no build step will collect or transform assets.

**Examples (from repo)**:
- Change the page title in `Academic Folder/Accademic.html` by editing the `<title>` element near the top of the file.
- Replace an image by overwriting the same filename in `Image/` to keep references working.

**When to ask the human**:
- If you need to rename files or folders (for spelling fixes or restructuring).
- If proposing to add a build tool, package manager, linter, or test framework.
- If a change will affect external links, integrations, or hosting configuration.

If anything in this file is unclear or you want more detail (preview commands for a different tool, or a checklist for publishing), ask and I will iterate.
